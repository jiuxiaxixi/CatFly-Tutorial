/*
 * Implementation of multithreading in ARM Cortex-M3. To be done.
 */


#ifndef __MTARCH_H__
#define __MTARCH_H__

struct mtarch_thread {
  long mt_thread;
};

#endif /* __MTARCH_H__ */